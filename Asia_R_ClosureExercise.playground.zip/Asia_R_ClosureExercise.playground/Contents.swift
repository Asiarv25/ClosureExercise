import UIKit


var MultiplyNum = ({(First: Int, Last: Int) ->Int in
    
    return First*Last });

print(MultiplyNum(3,247))
